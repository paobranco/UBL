
.onUnload <- function (libpath) {
  library.dynam.unload("UBL", libpath)
}
